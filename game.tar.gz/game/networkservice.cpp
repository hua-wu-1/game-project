#include "networkservice.h"
#include <QNetworkDatagram>

const quint16 NETWORK_PORT = 12345;

const QString NetworkService::POSITION_PERFIX = "POS:";

NetworkService::NetworkService(QObject *parent) : QObject(parent), m_server(new QTcpServer(this)), m_socket(nullptr)
{
    connect(m_server, &QTcpServer::newConnection, this, &NetworkService::handleNewConnection);
    // &QTcpServer::newConnection官方提供，新连接的时候自动发送信号

    findLocalIP();
    //查找本机ip
}

void NetworkService::findLocalIP()
{
    foreach (const QNetworkInterface &interface,
             QNetworkInterface::allInterfaces()) //遍历当前计算机上全部的网络接口，寻找存在的网络接口，参数：当前接口，所有接口
    {
        if (interface.flags().testFlag(QNetworkInterface::IsUp)
            && !interface.flags().testFlag(QNetworkInterface::IsLoopBack)) //检查存在的网络接口中启动的接口，并且排除环路
        {
            foreach (const QNetworkAddressEntry &entry, interface.addressEntries()) //处理一个电脑的多个ip的情况
            {
                if (entry.ip().protocol() == QAbstractSocket::IPv4Protocol) //寻找第一个ipv4
                {
                    m_localIP = entry.ip().toString(); //将获得地址转化成字符
                    return;
                }
            }
        }
    }
} //获取本机的ip地址

void NetworkService::setStatus(const QString &status)
{
    if (m_status != status) {
        m_status = status;
        emit statusChanged(status);
    }
} //检查网络状态是否改变

void NetworkService::startServer()
{
    if (m_isConnected) disconnect(); //如果当前有连接，则清除连接，服务器，客户端都会断开

    //设置主机为服务器
    m_isHost = true;
    //发送主机作为服务器的信号
    emit roleChanged(true);

    //断开服务器的监听
    if (m_server->isListening()) { m_server->close(); }

    if (m_server->listen(QHostAddress::Any, NETWORK_PORT)) //启动监听，监听所有网络接口ipv4+ipv6，端口号
    {
        setStatus(QString("Server running at %1:%2").arg(m_localIP).arg(NETWORK_PORT));
        emit connectionChanged(true);
        m_isConnected = true;
    } else {
        emit connectionError(QString("Failed to start server: %1").arg(m_server->errorString()));
    }
} //开启连接，启动服务器

void NetworkService::connectToServer(const QString &ip)
{
    if (m_isConnected) disconnect(); //作为客户端，先断开连接

    m_isHost = false; //设置为非服务器
    emit roleChanged(false);

    if (m_socket) {
        m_socket->deleteLater();
        m_socket = nullptr;
    } //清除之前连接的服务器

    m_socket = new QTcpSocket(this); //创建连接的套接字

    connect(m_socket, &QTcpSocket::connected, this, [this]() {
        emit connectionChanged(true);
        m_isConnected = true;
        setStatus(QString("Connected to %1").arg(m_socket->peerAddress().toString())); //获取服务器的ip
    });

    connect(m_socket,
            &QTcpSocket::readyRead,
            this,
            &NetworkService::handleReadyRead); //服务器发送信号，后客户端调用函数接受
    connect(m_socket, &QTcpSocket::disconnected, this, &NetworkService::handleDisconnected); //断开连接
    connect(m_socket,
            QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::errorOccurred),
            this,
            &NetworkService::handleSocketError); //当网络错误时，执行函数

    m_socket->connectToHost(ip, NETWORK_PORT);         //连接到服务器，需要获得ip
    setStatus(QString("Connecting to %1...").arg(ip)); //输出连接中消息
} //作为客户端，连接到服务器

void NetworkService::sendMessage(const QString &message)
{
    if (!m_isConnected) return;

    const QByteArray data = message.toUtf8(); //将message转化为网络可接受的字节序列

    if (m_isHost) {
        // 作为服务器 - 广播给所有客户端
        for (QTcpSocket *client : m_clients) {
            client->write(data); //发送消息
        }
        emit messageReceived(m_localIP, message);
    } else {
        // 作为客户端 - 发送给服务器
        if (m_socket && m_socket->isWritable()) //确认套接字存在，并且通道可以
        {
            m_socket->write(data);
            emit messageReceived("客户端", message);
        }
    }
} //处理服务器，客户端发送的消息

void NetworkService::disconnect()
{
    if (m_isHost) {
        // 关闭服务器
        m_server->close();

        // 断开所有客户端
        for (QTcpSocket *client : m_clients) {
            client->disconnectFromHost();
            client->deleteLater();
        }
        m_clients.clear();
    } else {
        // 断开客户端连接
        if (m_socket) { m_socket->disconnectFromHost(); }
    }

    m_isConnected = false;
    emit connectionChanged(false);
    setStatus("Disconnected");
} //断开服务器，客户端连接

void NetworkService::handleNewConnection()
{
    QTcpSocket *clientSocket
        = m_server->nextPendingConnection(); //在服务器中，获取下一个等待的客户端连接，获取的是一个客户端连接
    if (!clientSocket) return;

    connect(clientSocket,
            &QTcpSocket::readyRead,
            this,
            &NetworkService::handleReadyRead); //服务器发送信号，后客户端调用函数接受
    connect(clientSocket, &QTcpSocket::disconnected, this, &NetworkService::handleDisconnected);

    m_clients.append(clientSocket); //将当前客户端假如到服务器
    setStatus(QString("Client connected: %1").arg(clientSocket->peerAddress().toString()));

    // 新连接时发送欢迎消息
    QString welcome = QString("[System] Client %1 connected").arg(clientSocket->peerAddress().toString());
    clientSocket->write(welcome.toUtf8()); //像客户端发送消息
} //当新客户端连接时触发，在服务器端

void NetworkService::handleReadyRead()
{
    // 确定消息来源
    QTcpSocket *senderSocket = qobject_cast<QTcpSocket *>(sender());
    if (!senderSocket) return;

    while (senderSocket->bytesAvailable() > 0) {
        QByteArray data = senderSocket->readLine().trimmed();
        if (data.isEmpty()) continue;

        QString message = QString::fromUtf8(data);
        QString senderIP = senderSocket->peerAddress().toString();

        // 处理消息
        if (message.startsWith("[System]")) {
            setStatus(message);
        } else {
            emit messageReceived(senderIP, message);

            // 如果是服务器，广播给其他客户端
            if (m_isHost) {
                for (QTcpSocket *client : m_clients) {
                    if (client != senderSocket) { client->write(data + '\n'); }
                }
            }
        }

        //玩家位置处理
        if (message.startsWith(POSITION_PERFIX)) {
            QString posData = message.mid(POSITION_PERFIX.length()); //删除标志符"POS："

            QStringList coords = posData.split(','); //分割“，”

            if (coords.size() == 2) {
                bool ok;
                float x = coords[0].toFloat(&ok); //取出x坐标，如果不符合要求，就continue
                if (!ok) continue;

                float y = coords[1].toFloat(&ok);
                if (!ok) continue;

                emit positionReceived(senderIP, x, y);
            }
        }
    }
}

void NetworkService::handleDisconnected()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket *>(sender());
    if (!socket) return;

    if (m_isHost) {
        m_clients.removeAll(socket);
        setStatus(QString("Client disconnected: %1").arg(socket->peerAddress().toString()));
    } else {
        setStatus("Disconnected from server");
        m_isConnected = false;
        emit connectionChanged(false);
    }

    socket->deleteLater();
}

void NetworkService::handleSocketError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)

    QTcpSocket *socket = qobject_cast<QTcpSocket *>(sender());
    if (socket) { emit connectionError(QString("Network error: %1").arg(socket->errorString())); }

    disconnect();
}

void NetworkService::sendPlayerState(float x, float y, float velocity, int lives, int coins, int direction, bool jumping)
{
    if (!m_isConnected) return;
    QString posMag = QString("%1%2,%3").arg(POSITION_PERFIX).arg(x).arg(y);
    sendMessage(posMag);
} //发送玩家位置
