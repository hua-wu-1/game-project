#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "networkservice.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    qmlRegisterType<NetworkService>("com.gamenet", 1, 0, "NetworkService");

    engine.loadFromModule("game", "Main");

    return app.exec();
}
