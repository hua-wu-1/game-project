#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>
#include <QtCore/qhash.h>
#include <QtCore/qstring.h>

namespace QmlCacheGeneratedCode {
namespace _qt_qml_game_Main_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_BlueRectangle_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_CheckCollision_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Platform_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Player_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Xray_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Game_Items_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Background_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_StateIcon_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_FristMap_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_UI_GamePage_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_UI_MainMenu_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_UI_MainMenuPage_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_UI_ModeSelectPage_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_UI_SettingDialog_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_GM_GameView_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Monsters_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_BGM_MainSet_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Player_Skill_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Gold_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_GM_GameFail_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_SkillIcon_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_CollectCoin_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_SecondMap_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_MapContainer_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Player_Attack_Space_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Player_Skill_Sprite_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Player_Sprite_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qt_qml_game_Monster_Sprite_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    ~Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Main.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Main_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/BlueRectangle.qml"), &QmlCacheGeneratedCode::_qt_qml_game_BlueRectangle_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/CheckCollision.qml"), &QmlCacheGeneratedCode::_qt_qml_game_CheckCollision_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Platform.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Platform_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Player.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Player_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Xray.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Xray_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Game_Items.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Game_Items_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Background.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Background_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/StateIcon.qml"), &QmlCacheGeneratedCode::_qt_qml_game_StateIcon_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/FristMap.qml"), &QmlCacheGeneratedCode::_qt_qml_game_FristMap_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/UI_GamePage.qml"), &QmlCacheGeneratedCode::_qt_qml_game_UI_GamePage_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/UI_MainMenu.qml"), &QmlCacheGeneratedCode::_qt_qml_game_UI_MainMenu_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/UI_MainMenuPage.qml"), &QmlCacheGeneratedCode::_qt_qml_game_UI_MainMenuPage_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/UI_ModeSelectPage.qml"), &QmlCacheGeneratedCode::_qt_qml_game_UI_ModeSelectPage_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/UI_SettingDialog.qml"), &QmlCacheGeneratedCode::_qt_qml_game_UI_SettingDialog_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/GM_GameView.qml"), &QmlCacheGeneratedCode::_qt_qml_game_GM_GameView_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Monsters.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Monsters_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/BGM_MainSet.qml"), &QmlCacheGeneratedCode::_qt_qml_game_BGM_MainSet_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Player_Skill.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Player_Skill_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Gold.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Gold_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/GM_GameFail.qml"), &QmlCacheGeneratedCode::_qt_qml_game_GM_GameFail_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/SkillIcon.qml"), &QmlCacheGeneratedCode::_qt_qml_game_SkillIcon_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/CollectCoin.qml"), &QmlCacheGeneratedCode::_qt_qml_game_CollectCoin_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/SecondMap.qml"), &QmlCacheGeneratedCode::_qt_qml_game_SecondMap_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/MapContainer.qml"), &QmlCacheGeneratedCode::_qt_qml_game_MapContainer_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Player_Attack_Space.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Player_Attack_Space_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Player_Skill_Sprite.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Player_Skill_Sprite_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Player_Sprite.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Player_Sprite_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qt/qml/game/Monster_Sprite.qml"), &QmlCacheGeneratedCode::_qt_qml_game_Monster_Sprite_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.structVersion = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
}

Registry::~Registry() {
    QQmlPrivate::qmlunregister(QQmlPrivate::QmlUnitCacheHookRegistration, quintptr(&lookupCachedUnit));
}

const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_qmlcache_appgame)() {
    ::unitRegistry();
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_qmlcache_appgame))
int QT_MANGLE_NAMESPACE(qCleanupResources_qmlcache_appgame)() {
    return 1;
}
