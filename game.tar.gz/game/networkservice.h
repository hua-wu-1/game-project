#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QNetworkInterface>

class NetworkService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool isHost READ isHost NOTIFY roleChanged)
    Q_PROPERTY(bool isConnected READ isConnected NOTIFY connectionChanged)
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    Q_PROPERTY(QString localIP READ localIP CONSTANT)

public:
    explicit NetworkService(QObject *parent = nullptr);

    // 模式选择
    Q_INVOKABLE void startServer();
    Q_INVOKABLE void connectToServer(const QString &ip);
    Q_INVOKABLE void disconnect();

    // 发送消息
    Q_INVOKABLE void sendMessage(const QString &message);

    // 属性获取方法
    bool isHost() const { return m_isHost; }
    bool isConnected() const { return m_isConnected; }
    QString status() const { return m_status; }
    QString localIP() const { return m_localIP; }

signals:
    void messageReceived(const QString &senderIP, const QString &message);
    void connectionChanged(bool connected);
    void roleChanged(bool isHost);
    void statusChanged(const QString &status);
    void connectionError(const QString &error);

private slots:
    void handleNewConnection();
    void handleReadyRead();
    void handleDisconnected();
    void handleSocketError(QAbstractSocket::SocketError socketError);

private:
    void setStatus(const QString &status);
    void findLocalIP();

    QTcpServer *m_server;
    QTcpSocket *m_socket;          // 作为客户端时的连接
    QList<QTcpSocket *> m_clients; // 作为服务器时的客户端列表

    bool m_isHost = false;
    bool m_isConnected = false;
    QString m_status = "Disconnected";
    QString m_localIP = "127.0.0.1";
};
