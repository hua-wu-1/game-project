#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QNetworkInterface>

class NetworkService : public QObject
{
    Q_OBJECT

    //通过Q_PROPERTY暴露给qml,同时进行属性绑定，暴露的是属性

    //参数：    bool 类型    isHost 属性名字    READ isHost 读取函数是isHost()   NOTIFY roleChanged 当属性变化的时候发出信号
    Q_PROPERTY(bool isHost READ isHost NOTIFY roleChanged)
    Q_PROPERTY(bool isConnected READ isConnected NOTIFY connectionChanged)
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    Q_PROPERTY(QString localIP READ localIP CONSTANT)
    //CONSTANT表明属性是常量，初始化后不会改变

public:
    explicit NetworkService(QObject *parent = nullptr);

    // 模式选择

    //Q_INVOKABLE暴露的是函数，qml可以使用这些函数
    Q_INVOKABLE void startServer();
    Q_INVOKABLE void connectToServer(const QString &ip); //引用
    Q_INVOKABLE void disconnect();

    // 发送消息
    Q_INVOKABLE void sendMessage(const QString &message);
    Q_INVOKABLE void sendPlayerState(float x, float y, float velocity, int lives, int coins, int direction, bool jumping);

    // 属性获取方法
    bool isHost() const { return m_isHost; }
    bool isConnected() const { return m_isConnected; }
    QString status() const { return m_status; }
    QString localIP() const { return m_localIP; }

    static const QString POSITION_PERFIX; //定义人物位置标识符

signals:
    void messageReceived(const QString &senderIP, const QString &message);
    void connectionChanged(bool connected);
    void roleChanged(bool isHost);
    void statusChanged(const QString &status);
    void connectionError(const QString &error);

    void positionReceived(const QString &senderIP, float x, float y);
    void playerStateReceived(const QString &senderIP,
                             float velocity,
                             int lives,
                             int coins,
                             int direction,
                             bool jumping,
                             const QJsonArray &states,
                             const QJsonArray &skills);

private slots:
    void handleNewConnection();
    void handleReadyRead();
    void handleDisconnected();
    void handleSocketError(QAbstractSocket::SocketError socketError);

private:
    void setStatus(const QString &status);
    void findLocalIP();

    QTcpServer *m_server;          // 服务器用于监听
    QTcpSocket *m_socket;          // 作为客户端时的连接
    QList<QTcpSocket *> m_clients; // 作为服务器时的客户端列表

    bool m_isHost = false;
    bool m_isConnected = false;
    QString m_status = "Disconnected";
    QString m_localIP = "127.0.0.1";
};
